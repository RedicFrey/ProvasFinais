use sakila;


# -- 1º questão
create or replace view v_filmes_acao as(
select title, release_year as "ano de lancamento", rating as classificacao, length as duracao
from film
inner join film_category using (film_id)
inner join category using(category_id)
where category.name = 'Action');

# -- 2° questão

use classicmodels;

create table tabela_clientes_limite as 
select customername as nome, country as pais, creditlimit as limite, 
 case
  when creditlimit > 100000 then "alto"
  when creditlimit between 50000 and 100000 then "medio"
  else "baixo"
 end as analise
from customers;

# -- 3º questão 

use world;
describe countrylanguage;
describe country;


delimiter $
create procedure sp_update_language (in param_cod_pais varchar(3), in param_idioma varchar(30), param_porcentagem decimal(4,1))
begin

 declare var_saida varchar(200);

-- select
 select countrycode, language, Percentage from countrylanguage where countrycode = param_cod_pais and language = param_idioma and percentage= param_porcentagem;
 -- update
 update countrylanguage  set percentage = param_porcentagem where countrycode = param_cod_pais and language = param_idioma;

 set var_saida = concat('O país de codigo ', param_cod_pais ,' e idioma ', param_idioma, ' teve a porcentage alterada para ', param_porcentagem, ' com sucesso!');
 select var_saida;
end$
delimiter ;

-- caso de erro
drop procedure sp_update_language;
-- teste
call sp_update_language('BDI', 'French', 0.1);

# -- 4º questão 

with cte_questao4 as (select region, sum(population) populacao_total from country group by region order by populacao_total desc)
select * from cte_questao4 where populacao_total > 50000000;

# -- 5º questão

use classicmodels;

create or replace view v_analise_vendas as (
select productcode as codigo_produto, productname as nome_produto, quantityinstock as quantidade, msrp as preco_sugerido from products where productline = 'planes');


describe products;

create table ANALISE_AVIOES(
 produto varchar(70),
 status varchar(200)
);

delimiter $
create procedure potencial_estoque ()
begin
 declare nome_produto varchar(70);
 declare cod_produto varchar(15);
 declare preco_sugerido decimal(10,2);
 declare estoque int;
 declare var_observado varchar(200);
 
 declare cursor1 cursor for select codigo_produto, productname, quantidade, preco_sugerido from v_analise_vendas;
 
 declare continue handler for
   not found set done = true;
   
    #abrir o cursor
  
  open cursor1;
  
  process_lista:loop
    fetch cursor1 into nome_produto, cod_produto, estoque, preco_sugerido;
    
    if done then
     leave process_lista;
	end if;
 
 if FORMAT((quantityInStock * MSRP), 2) < 50000 
  then set var_observado = 'Baixo potencial de receita.';
 elseif FORMAT((quantityInStock * MSRP), 2) between 50000 and 500000
  then set var_observado = 'Potencial dentro da media';
 else 
  set var_observado = 'produto de alto valor financeiro';
 end if;
  
  insert into ANALISE_AVIOES values (nome_produto, cod_produto, pedido, var_observado);
  end loop;
 close cursor1;
end$
delimiter ;