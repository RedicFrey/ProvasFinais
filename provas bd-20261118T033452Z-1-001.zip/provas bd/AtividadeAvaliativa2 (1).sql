create database if not exists LojaBancoDados2;
use LojaBancoDados2;

-- 1. tabelas

create table Produto(
    CodigoProduto int primary key auto_increment, 
    nome varchar(50) not null, 
    descricao text, 
    qtde_estoque int not null
) engine = InnoDB;

create table Cliente(
    CodigoCliente int primary key auto_increment, 
    nome varchar(50) not null,
    email varchar(100) not null,
    cpf varchar(15) not null
) engine = InnoDB;

create table Pedido(
    CodigoPedido int primary key auto_increment,
    dataPedido datetime default current_timestamp,
    status varchar(15)
) engine = InnoDB;

create table ItemPedido(
    CodigoPedido int,
    CodigoProduto int,
    PrecoVenda decimal(10,2) not null,
    Qtde int not null,
    CONSTRAINT fk_pedido FOREIGN KEY (CodigoPedido) REFERENCES Pedido(CodigoPedido),
    CONSTRAINT fk_produto FOREIGN KEY (CodigoProduto) REFERENCES Produto(CodigoProduto)
) engine = InnoDB;

create table Funcionario (
    CodigoFuncionario int primary key auto_increment,
    nome varchar(60) not null,
    funcao varchar(20) not null,
    cidade varchar(60)
) engine = InnoDB;

create table Auditoria (
    DataModificao datetime default current_timestamp,
    nometabela varchar(20) not null,
    historico varchar(200) not null
) engine = InnoDB;


# --  triggers (produto)

delimiter $

create trigger trg_insert_produto after Insert on Produto for each row
begin
    insert into Auditoria(nometabela, historico) 
    values ('Produto', concat('O produto código ', new.CodigoProduto, ' ("', new.nome, '") foi criado.'));
end$

create trigger trg_update_produto after Update on Produto for each row
begin
    declare var_alteracao varchar(200) default '';
    
    if old.nome <> new.nome then
        set var_alteracao = concat(var_alteracao, 'Nome de "', old.nome, '" para "', new.nome, '"; ');
    end if;
    
    if ifnull(old.descricao, '') <> ifnull(new.descricao, '') then
        set var_alteracao = concat(var_alteracao, 'Descrição alterada; ');
    end if;
    
    if old.qtde_estoque <> new.qtde_estoque then
        set var_alteracao = concat(var_alteracao, 'Estoque de ', old.qtde_estoque, ' para ', new.qtde_estoque, '; ');
    end if;
    
    if var_alteracao <> '' then
        insert into Auditoria(nometabela, historico) 
        values ('Produto', concat('O produto código ', old.CodigoProduto, ' alterou: ', var_alteracao));
    end if;
end$

create trigger trg_delete_produto after Delete on Produto for each row
begin
    insert into Auditoria(nometabela, historico) 
    values ('Produto', concat('O produto código ', old.CodigoProduto, ' ("', old.nome, '", Estoque: ', old.qtde_estoque, ') foi excluído.'));
end$

delimiter ;

# -- triggers (cliente)

delimiter $

create trigger trg_insert_cliente after Insert on Cliente for each row
begin
    insert into Auditoria(nometabela, historico) 
    values ('Cliente', concat('O cliente código ', new.CodigoCliente, ' ("', new.nome, '") foi adicionado.'));
end$

create trigger trg_update_cliente after Update on Cliente for each row
begin
    declare var_alteracao varchar(200) default '';
    
    if old.nome <> new.nome then
        set var_alteracao = concat(var_alteracao, 'Nome de "', old.nome, '" para "', new.nome, '"; ');
    end if;

    if old.email <> new.email then
        set var_alteracao = concat(var_alteracao, 'Email de "', old.email, '" para "', new.email, '"; ');
    end if;

    if old.cpf <> new.cpf then
        set var_alteracao = concat(var_alteracao, 'CPF de "', old.cpf, '" para "', new.cpf, '"; ');
    end if;
    
    if var_alteracao <> '' then
        insert into Auditoria(nometabela, historico) 
        values ('Cliente', concat('O cliente código ', old.CodigoCliente, ' alterou: ', var_alteracao));
    end if;
end$

create trigger trg_delete_cliente after Delete on Cliente for each row
begin
    insert into Auditoria(nometabela, historico) 
    values ('Cliente', concat('O cliente código ', old.CodigoCliente, ' ("', old.nome, '", CPF: ', old.cpf, ') foi excluído.'));
end$

delimiter ;

# -- triggers (pedido)

delimiter $

create trigger trg_insert_pedido after Insert on Pedido for each row
begin
    insert into Auditoria(nometabela, historico) 
    values ('Pedido', concat('O pedido código ', new.CodigoPedido, ' foi criado com status: ', ifnull(new.status, 'Pendente')));
end$

create trigger trg_update_pedido after Update on Pedido for each row
begin
    declare var_alteracao varchar(200) default '';
    
    if ifnull(old.status, '') <> ifnull(new.status, '') then
        set var_alteracao = concat(var_alteracao, 'Status de "', ifnull(old.status, 'vazio'), '" para "', new.status, '"; ');
    end if;
    
    if var_alteracao <> '' then
        insert into Auditoria(nometabela, historico) 
        values ('Pedido', concat('O pedido código ', old.CodigoPedido, ' alterou: ', var_alteracao));
    end if;
end$

create trigger trg_delete_pedido after Delete on Pedido for each row
begin
    insert into Auditoria(nometabela, historico) 
    values ('Pedido', concat('O pedido código ', old.CodigoPedido, ' (Status final: ', ifnull(old.status, 'N/A'), ') foi excluído.'));
end$

delimiter ;

# --  triggers (itempedido)

delimiter $

create trigger trg_insert_itempedido after Insert on ItemPedido for each row
begin
    insert into Auditoria(nometabela, historico) 
    values ('ItemPedido', concat('Item inserido no pedido ', new.CodigoPedido, ': Produto ', new.CodigoProduto, ', Qtde: ', new.Qtde, ', Preço: ', new.PrecoVenda));
end$

create trigger trg_update_itempedido after Update on ItemPedido for each row
begin
    declare var_alteracao varchar(200) default '';
    
    if old.PrecoVenda <> new.PrecoVenda then
        set var_alteracao = concat(var_alteracao, 'Preço de ', old.PrecoVenda, ' para ', new.PrecoVenda, '; ');
    end if;

    if old.Qtde <> new.Qtde then
        set var_alteracao = concat(var_alteracao, 'Quantidade de ', old.Qtde, ' para ', new.Qtde, '; ');
    end if;
    
    if var_alteracao <> '' then
        insert into Auditoria(nometabela, historico) 
        values ('ItemPedido', concat('O item do pedido ', old.CodigoPedido, ' (Produto ', old.CodigoProduto, ') alterou: ', var_alteracao));
    end if;
end$

create trigger trg_delete_itempedido after Delete on ItemPedido for each row
begin
    insert into Auditoria(nometabela, historico) 
    values ('ItemPedido', concat('Item removido do pedido ', old.CodigoPedido, ': Produto ', old.CodigoProduto, ', Qtde: ', old.Qtde, ', Preço: ', old.PrecoVenda));
end$

delimiter ;

# -- triggers (funcionário)

delimiter $

create trigger trg_insert_funcionario after Insert on Funcionario for each row
begin
    insert into Auditoria(nometabela, historico) 
    values ('Funcionario', concat('O funcionário código ', new.CodigoFuncionario, ' ("', new.nome, '") foi criado.'));
end$

create trigger trg_update_funcionario after Update on Funcionario for each row
begin
    declare var_alteracao varchar(200) default '';
    
    if old.nome <> new.nome then
        set var_alteracao = concat(var_alteracao, 'Nome de "', old.nome, '" para "', new.nome, '"; ');
    end if;

    if old.funcao <> new.funcao then
        set var_alteracao = concat(var_alteracao, 'Função de "', old.funcao, '" para "', new.funcao, '"; ');
    end if;

    if ifnull(old.cidade, '') <> ifnull(new.cidade, '') then
        set var_alteracao = concat(var_alteracao, 'Cidade de "', ifnull(old.cidade, 'vazio'), '" para "', new.cidade, '"; ');
    end if;
    
    if var_alteracao <> '' then
        insert into Auditoria(nometabela, historico) 
        values ('Funcionario', concat('O funcionário código ', old.CodigoFuncionario, ' alterou: ', var_alteracao));
    end if;
end$

create trigger trg_delete_funcionario after Delete on Funcionario for each row
begin
    insert into Auditoria(nometabela, historico) 
    values ('Funcionario', concat('O funcionário código ', old.CodigoFuncionario, ' ("', old.nome, '", Cargo: ', old.funcao, ') foi excluído.'));
end$

delimiter ;

-- 7. Criar uma procedure para cada tabela para inserir os dados, exceto para Pedido e ItemPedido.

delimiter $

create procedure sp_inserir_produto(in param_nome varchar(50), in param_descricao text, in param_qtde_estoque int)
begin
    insert into Produto(nome, descricao, qtde_estoque) values (param_nome, param_descricao, param_qtde_estoque);
end$

create procedure sp_inserir_cliente(in param_nome varchar(50), in param_email varchar(100), in param_cpf varchar(15))
begin
    insert into Cliente(nome, email, cpf) values (param_nome, param_email, param_cpf);
end$

create procedure sp_inserir_funcionario(in param_nome varchar(60), in param_funcao varchar(20), in param_cidade varchar(60))
begin
    insert into Funcionario(nome, funcao, cidade) values (param_nome, param_funcao, param_cidade);
end$

-- 6 - Criar a JSON Carrinho (CodigoProduto, CodigoCliente, CodigoVendedor, Qtde). Aplicar JSON extract
create table Carrinho (
    CodigoCarrinho int primary key auto_increment,
    dados json not null
) engine = InnoDB;

# -> inserir e testar tabela

insert into Carrinho(dados) values (
	'{"CodigoProduto": 1,
	"CodigoCliente": 2,
	"CodigoVendedor": 3,
	"Qtde": 5
    }'
);

select codigoCarrinho,
JSON_EXTRACT(dados, '$.CodigoProduto') as CodigoProduto,
JSON_EXTRACT(dados, '$.CodigoCliente') as CodigoCliente,
JSON_EXTRACT(dados, '$.CodigoVendedor') as CodigoVendedor,
JSON_EXTRACT(dados, '$.Qtde') as Qtde
from Carrinho;

-- 7 - Criar um procedure para inserir Pedido e ItemPedido precisa ter: Transação, Cursor e validações. 
create procedure sp_processar_pedido_json(in param_carrinho_json JSON, out param_mensagem varchar(200))
proc_block: begin
    declare done int default false;
    declare var_codigo_produto int;
    declare var_qtde int;
    declare var_preco decimal(10,2);
    declare var_estoque_atual int;
    declare var_codigo_pedido int;

    declare cursor1 cursor for
        select
            jsont.CodigoProduto,
            jsont.Qtde,
            jsont.PrecoVenda
        from JSON_TABLE(param_carrinho_json, '$.itens[*]' columns (
            CodigoProduto int path '$.CodigoProduto',
            Qtde int path '$.Qtde',
            PrecoVenda decimal(10,2) path '$.PrecoVenda'
        )) as jsont;

    declare continue handler for not found set done = true;

    set param_mensagem = 'Sucesso';

    start transaction;

    insert into Pedido(status) values ('Pendente');
    set var_codigo_pedido = last_insert_id();

    open cursor1;

    read_loop: loop
        fetch cursor1 into var_codigo_produto, var_qtde, var_preco;
        if done then
            leave read_loop;
        end if;

        if var_qtde <= 0 then
            set param_mensagem = 'Erro: quantidade inválida no carrinho.';
            close cursor1;
            rollback;
            leave proc_block;
        end if;

        if var_preco is null or var_preco <= 0 then
            set param_mensagem = 'Erro: preço inválido no carrinho.';
            close cursor1;
            rollback;
            leave proc_block;
        end if;

        set var_estoque_atual = null;

        select qtde_estoque into var_estoque_atual
        from Produto
        where CodigoProduto = var_codigo_produto
        for update;

        if var_estoque_atual is null then
            set param_mensagem = concat('Erro: produto codigo ', var_codigo_produto, ' nao existe.');
            close cursor1;
            rollback;
            leave proc_block;
        elseif var_estoque_atual < var_qtde then
            set param_mensagem = concat('Erro: estoque insuficiente para o produto codigo ', var_codigo_produto, '.');
            close cursor1;
            rollback;
            leave proc_block;
        else
            insert into ItemPedido(CodigoPedido, CodigoProduto, PrecoVenda, Qtde)
            values (var_codigo_pedido, var_codigo_produto, var_preco, var_qtde);

            update Produto
            set qtde_estoque = qtde_estoque - var_qtde
            where CodigoProduto = var_codigo_produto;
        end if;
    end loop;

    close cursor1;

    update Pedido set status = 'concluido' where CodigoPedido = var_codigo_pedido;

    commit;
end$

delimiter ;

-- 8.  Criar uma View para visualizar os Produtos mais vendidos.

create or replace view produtos_mais_vendidos as (
    select 
        p.CodigoProduto,
        p.nome as NomeProduto,
        p.descricao,
        SUM(ip.Qtde) as TotalVendido,
        SUM(ip.Qtde * ip.PrecoVenda) as ReceitaTotal
    from Produto as p
    inner join ItemPedido as ip on p.CodigoProduto = ip.CodigoProduto
    group by p.CodigoProduto, p.nome, p.descricao
    order by TotalVendido desc
);