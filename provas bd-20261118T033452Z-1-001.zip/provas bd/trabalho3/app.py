from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

st.set_page_config(page_title="Curso Superior", page_icon="👩‍🎓", layout="wide")

# ------------------------------------------------------------------ constantes
COR_MULHERES = "#d4537e"
COR_HOMENS = "#2a78d6"
COR_APAGADA = "#d9d9d9"

AREAS = {
    "CTEM (Exatas)": "CTEM",
    "Educação, Serviços e Saúde": "EDU",
}
AREA_DESCRICAO = {
    "CTEM (Exatas)": "Ciência, Tecnologia, Engenharias e Matemática",
    "Educação, Serviços e Saúde": "Educação, Serviços pessoais, Saúde e Bem-estar",
}

PADRAO = ["Sudeste", "Minas Gerais", "Espírito Santo", "Rio de Janeiro",
          "São Paulo", "Paraná", "Mato Grosso do Sul"]

REGIOES = {
    "Norte": ["Rondônia", "Acre", "Amazonas", "Roraima", "Pará", "Amapá", "Tocantins"],
    "Nordeste": ["Maranhão", "Piauí", "Ceará", "Rio Grande do Norte", "Paraíba",
                 "Pernambuco", "Alagoas", "Sergipe", "Bahia"],
    "Sudeste": ["Minas Gerais", "Espírito Santo", "Rio de Janeiro", "São Paulo"],
    "Sul": ["Paraná", "Santa Catarina", "Rio Grande do Sul"],
    "Centro-Oeste": ["Mato Grosso do Sul", "Mato Grosso", "Goiás", "Distrito Federal"],
}
UF_REGIAO = {uf: reg for reg, ufs in REGIOES.items() for uf in ufs}
AGREGADOS = ["Brasil", *REGIOES.keys()]

PASTA_IMG = Path(__file__).parent / "imagens"


def imagem(nome, legenda):
    """Mostra uma imagem da pasta 'imagens' ao lado do app.py."""
    caminho = PASTA_IMG / nome
    if caminho.exists():
        st.image(str(caminho), caption=legenda, width="stretch")
    else:
        st.caption(f"Imagem não encontrada: imagens/{nome}")

def pct_txt(v: float) -> str:
    return f"{v:.1f}".replace(".", ",") + "%"


def num_txt(v: float) -> str:
    return f"{v:,.0f}".replace(",", ".")


@st.cache_data
def carregar_dados() -> pd.DataFrame:
    arquivos = sorted(Path(__file__).parent.glob("Tabela_3*.xlsx"))
    if not arquivos:
        st.error("Planilha 'Tabela_3_Areas_gerais_de_formacao_na_graduacao' não encontrada "
                 "na mesma pasta do app.py.")
        st.stop()

    cols = ["Local",
            "Sup_Total", "Sup_Homens", "Sup_Mulheres",
            "CTEM_Total", "CTEM_Homens", "CTEM_Mulheres",
            "EDU_Total", "EDU_Homens", "EDU_Mulheres"]
    df = pd.read_excel(arquivos[0], engine="openpyxl", header=None,
                       skiprows=3, usecols="A:J", names=cols)
    df = df[df["Sup_Total"].notna()].copy()
    df["Local"] = df["Local"].str.strip()
    df = df.reset_index(drop=True)
    return df


df = carregar_dados()
todos_locais = df["Local"].tolist()


def pct_mulheres(linha, area: str) -> float:
    """% de mulheres entre os diplomados da área (Homens + Mulheres)."""
    h, m = linha[f"{area}_Homens"], linha[f"{area}_Mulheres"]
    return m / (h + m) * 100


def pct_area_do_sexo(linha, area: str, sexo: str) -> float:
    """% das pessoas diplomadas de um sexo que estão numa área."""
    return linha[f"{area}_{sexo}"] / linha[f"Sup_{sexo}"] * 100


# side bar cmc
with st.sidebar:
    st.header("Filtros", divider="red")

    locais = st.multiselect(
        "Estados e regiões",
        todos_locais,
        default=[l for l in PADRAO if l in todos_locais],
        help="Escolha o que aparece nos gráficos de comparação.",
    )

    sexo = st.radio("Sexo", ("Ambos", "Feminino", "Masculino"),
                    help="Em 'Feminino' ou 'Masculino' o sexo escolhido fica colorido "
                         "e o outro fica em cinza.")

    areas_sel = st.multiselect(
        "Área do conhecimento",
        list(AREAS.keys()),
        default=list(AREAS.keys()),
    )

    st.divider()
    destaque = st.selectbox(
        "Local em destaque (KPIs)",
        todos_locais,
        index=todos_locais.index("Sudeste") if "Sudeste" in todos_locais else 0,
    )

    st.caption("A planilha do Censo não tem coluna de ano, por isso não há filtro de ano.")
# side bar fim


# título 
st.markdown(
    "<h1 style='font-size: 28px;'>Ensino superior e a presença feminina "
    "nas áreas de Exatas e Humanas</h1>",
    unsafe_allow_html=True,
)
st.caption("Fonte: IBGE, Censo Demográfico (Tabela 10063): pessoas com nível superior "
           "completo, por área geral de formação. Os dados mostram quem **já tem diploma** "
           "(estoque), não ingressantes.")

if not locais or not areas_sel:
    st.warning("Escolha pelo menos um estado/região e uma área do conhecimento na barra lateral.")
    st.stop()

# mantém a ordem da planilha (Brasil, regiões, UFs)
locais = [l for l in todos_locais if l in locais]
dados = df.set_index("Local", drop=False)

st.subheader(f"Indicadores: {destaque}")
lin = dados.loc[destaque]
br = dados.loc["Brasil"]

if sexo == "Ambos":
    total_kpi, rotulo_total = lin["Sup_Total"], "Pessoas com nível superior"
else:
    s = "Mulheres" if sexo == "Feminino" else "Homens"
    total_kpi, rotulo_total = lin[f"Sup_{s}"], f"{'Mulheres' if s == 'Mulheres' else 'Homens'} com nível superior"


def delta_br(valor, ref):
    return f"{valor - ref:+.1f}".replace(".", ",") + " p.p. vs Brasil"


k1, k2, k3, k4 = st.columns(4)
k1.metric(rotulo_total, num_txt(total_kpi))

v = pct_mulheres(lin, "CTEM")
k2.metric("Mulheres entre diplomados em CTEM", pct_txt(v),
          delta_br(v, pct_mulheres(br, "CTEM")), delta_color="off")

v = pct_mulheres(lin, "EDU")
k3.metric("Mulheres entre diplomados em Educação, Serviços e Saúde", pct_txt(v),
          delta_br(v, pct_mulheres(br, "EDU")), delta_color="off")

v = pct_area_do_sexo(lin, "CTEM", "Mulheres")
k4.metric("Das diplomadas, % que estão em CTEM", pct_txt(v),
          delta_br(v, pct_area_do_sexo(br, "CTEM", "Mulheres")), delta_color="off")

st.divider()


# helpers de gráfico
def cores_por_sexo(sexo_filtro: str) -> dict:
    if sexo_filtro == "Feminino":
        return {"Mulheres": COR_MULHERES, "Homens": COR_APAGADA}
    if sexo_filtro == "Masculino":
        return {"Mulheres": COR_APAGADA, "Homens": COR_HOMENS}
    return {"Mulheres": COR_MULHERES, "Homens": COR_HOMENS}


def sexo_visivel(s: str) -> bool:
    return (sexo == "Ambos"
            or (sexo == "Feminino" and s == "Mulheres")
            or (sexo == "Masculino" and s == "Homens"))


def limpar_titulos_facetas(fig):
    fig.for_each_annotation(lambda a: a.update(
        text=f"<b>{a.text.split('=')[-1]}</b>", font=dict(size=15)))


def layout_base(fig, altura):
    fig.update_layout(
        height=altura,
        legend=dict(orientation="h", yanchor="bottom", y=1.12, xanchor="left", x=0,
                    title_text="", font=dict(size=14)),
        margin=dict(l=10, r=10, t=90, b=40),
        bargap=0.28,
        font=dict(size=14),
        uniformtext=dict(minsize=12, mode="show"),
    )
    fig.update_yaxes(title=None, autorange="reversed", tickfont=dict(size=14))
    return fig


# abas
aba1, aba2, aba3, aba4, aba5 = st.tabs([
    "👩‍🎓 Gênero por área",
    "🎯 Escolha de área",
    "🗺️ Todas as UFs",
    "📄 Dados",
    "💬Noticias",
])

# ================= Aba 1: barras 100% empilhadas =================
with aba1:
    st.markdown("#### Quem são os diplomados de cada área?")
    st.caption("Cada barra soma 100% dos diplomados da área naquele local. "
               "A linha pontilhada marca 50%")

    linhas = []
    for loc in locais:
        for nome_area in areas_sel:
            cod = AREAS[nome_area]
            r = dados.loc[loc]
            pm = pct_mulheres(r, cod)
            for s, p in (("Mulheres", pm), ("Homens", 100 - pm)):
                linhas.append({"Local": loc, "Área": nome_area, "Sexo": s, "Percentual": p,
                               "Rótulo": pct_txt(p) if sexo_visivel(s) else ""})
    longo = pd.DataFrame(linhas)

    fig = px.bar(
        longo, y="Local", x="Percentual", color="Sexo", facet_col="Área",
        orientation="h", barmode="stack", text="Rótulo",
        color_discrete_map=cores_por_sexo(sexo),
        category_orders={"Local": locais, "Sexo": ["Mulheres", "Homens"],
                         "Área": areas_sel},
        hover_data={"Percentual": ":.1f", "Rótulo": False},
    )
    fig.update_traces(textposition="inside", insidetextanchor="middle",
                      textfont=dict(color="white", size=14))
    fig.update_xaxes(range=[0, 100], tickvals=[0, 25, 50, 75, 100], ticksuffix="%",
                     title=None)
    fig.add_vline(x=50, line_dash="dot", line_color="#555555", line_width=1.5)
    limpar_titulos_facetas(fig)
    layout_base(fig, max(380, 62 * len(locais) + 150))
    st.plotly_chart(fig, width="stretch")

    # leitura automática
    for nome_area in areas_sel:
        cod = AREAS[nome_area]
        serie = {l: pct_mulheres(dados.loc[l], cod) for l in locais}
        maior = max(serie, key=serie.get)
        menor = min(serie, key=serie.get)
        st.markdown(
            f"**{nome_area}:** entre os selecionados, a maior presença feminina é em "
            f"**{maior}** ({pct_txt(serie[maior])}) e a menor em **{menor}** "
            f"({pct_txt(serie[menor])})."
        )


# ================= Aba 2: escolha de área =================
with aba2:
    st.markdown("#### Para onde vão as mulheres e os homens diplomados?")
    st.caption("Cada barra mostra, entre as pessoas diplomadas de um sexo, "
               "qual % se formou naquela área.")

    linhas = []
    for loc in locais:
        r = dados.loc[loc]
        for nome_area in areas_sel:
            cod = AREAS[nome_area]
            for s in ("Mulheres", "Homens"):
                if not sexo_visivel(s):
                    continue
                p = pct_area_do_sexo(r, cod, s)
                linhas.append({"Local": loc, "Área": nome_area, "Sexo": s,
                               "Percentual": p, "Rótulo": pct_txt(p)})
    longo2 = pd.DataFrame(linhas)

    fig2 = px.bar(
        longo2, y="Local", x="Percentual", color="Sexo", facet_col="Área",
        orientation="h", barmode="group", text="Rótulo",
        color_discrete_map={"Mulheres": COR_MULHERES, "Homens": COR_HOMENS},
        category_orders={"Local": locais, "Sexo": ["Mulheres", "Homens"],
                         "Área": areas_sel},
        hover_data={"Percentual": ":.1f", "Rótulo": False},
    )
    fig2.update_traces(textposition="outside", cliponaxis=False)
    teto = max(longo2["Percentual"].max() * 1.2, 10)
    fig2.update_xaxes(range=[0, teto], ticksuffix="%", title=None)
    limpar_titulos_facetas(fig2)
    n_barras = 2 if sexo == "Ambos" else 1
    layout_base(fig2, max(420, (26 * n_barras + 30) * len(locais) + 150))
    st.plotly_chart(fig2, width="stretch")

    if "CTEM (Exatas)" in areas_sel and sexo == "Ambos":
        r = dados.loc[destaque]
        m = pct_area_do_sexo(r, "CTEM", "Mulheres")
        h = pct_area_do_sexo(r, "CTEM", "Homens")
        st.markdown(
            f"**Em {destaque}:** {pct_txt(m)} das mulheres diplomadas estão em CTEM, "
            f"contra {pct_txt(h)} dos homens diplomados."
        )

# Aba 3: todas as UFs 
with aba3:
    st.markdown("#### Ranking de todas as UFs")
    area_rank = st.radio("Área", list(AREAS.keys()), horizontal=True,
                         index=list(AREAS.keys()).index(areas_sel[0]))
    cod = AREAS[area_rank]

    ufs = df[~df["Local"].isin(AGREGADOS)].copy()
    ufs["Região"] = ufs["Local"].map(UF_REGIAO)
    ufs["Percentual"] = ufs.apply(lambda r: pct_mulheres(r, cod), axis=1)
    ufs = ufs.sort_values("Percentual", ascending=False)
    ufs["Rótulo"] = ufs["Percentual"].map(pct_txt)
    media_br = pct_mulheres(br, cod)

    st.caption(f"% de mulheres entre os diplomados em {area_rank}, nas 27 UFs. "
               "A linha mostra a média do Brasil.")

    fig3 = px.bar(
        ufs, y="Local", x="Percentual", color="Região", orientation="h", text="Rótulo",
        category_orders={"Local": ufs["Local"].tolist(),
                         "Região": ["Norte", "Nordeste", "Centro-Oeste", "Sudeste", "Sul"]},
        color_discrete_sequence=["#1b9e77", "#d95f02", "#7570b3", "#e7298a", "#e6ab02"],
        hover_data={"Percentual": ":.1f", "Rótulo": False},
    )
    fig3.update_traces(textposition="outside", cliponaxis=False)
    fig3.add_vline(x=media_br, line_dash="dash", line_color="#333333",
                   annotation_text=f"Brasil: {pct_txt(media_br)}",
                   annotation_position="top")
    fig3.update_xaxes(range=[0, ufs["Percentual"].max() * 1.12], ticksuffix="%", title=None)
    layout_base(fig3, 820)
    fig3.update_layout(legend=dict(y=1.04))
    st.plotly_chart(fig3, width="stretch")

    topo, base = ufs.iloc[0], ufs.iloc[-1]
    st.markdown(
        f"Maior presença feminina: **{topo['Local']}** ({pct_txt(topo['Percentual'])}). "
        f"Menor: **{base['Local']}** ({pct_txt(base['Percentual'])})."
    )

# Aba 4: dados
with aba4:
    st.markdown("#### Dados da planilha")
    tabela = df.rename(columns={
        "Sup_Total": "Superior (total)", "Sup_Homens": "Superior (homens)",
        "Sup_Mulheres": "Superior (mulheres)",
        "CTEM_Total": "CTEM (total)", "CTEM_Homens": "CTEM (homens)",
        "CTEM_Mulheres": "CTEM (mulheres)",
        "EDU_Total": "Educ./Serv./Saúde (total)", "EDU_Homens": "Educ./Serv./Saúde (homens)",
        "EDU_Mulheres": "Educ./Serv./Saúde (mulheres)",
    })
    st.dataframe(tabela, width="stretch", hide_index=True)


# Aba 5

def fontes(links):
    """Mostra as fontes como botões de link, um ao lado do outro."""
    st.caption("Fontes")
    cols_f = st.columns(len(links))
    for c, (nome, url) in zip(cols_f, links):
        c.link_button(nome, url, width="stretch")
 
 
with aba5:
    st.markdown("#### Notícias e contexto")
    st.caption("Três temas que ajudam a explicar os números do dashboard.")
 
    # ---------- 1. escassez de TI/Exatas ----------
    with st.container(border=True):
        st.markdown("### 💻 Escassez de profissionais de TI e Exatas")
 
        m1, m2 = st.columns([1, 2], vertical_alignment="center")
        m1.metric("Déficit estrutural de profissionais de TI", "+530 mil",
                  help="Dado de 2025 citado nas fontes abaixo.")
        m2.markdown(
            "O problema **ficou mais grave em 2025, não melhor**. A transformação digital "
            "avança em todos os setores e a inteligência artificial amplia a demanda por "
            "especialistas, então a conta entre oferta e demanda de mão de obra em "
            "tecnologia não fecha."
        )
        st.markdown(
            "A escassez de talentos aumenta a disputa por trabalhadores especializados, "
            "principalmente nestas áreas:"
        )
        a1, a2, a3, a4 = st.columns(4)
        a1.info("🤖 **Inteligência Artificial** e Machine Learning")
        a2.info("🛠️ **Engenharia de Software**")
        a3.info("🔒 **Cibersegurança**")
        a4.info("📊 **Ciência e Análise de Dados**")
 
        fontes([
            ("Monitor Mercantil", "https://monitormercantil.com.br/ti-faltam-profissionais-enquanto-salarios-chegam-a-r-27-mil/"),
            ("Nextage", "https://nextage.com.br/blog/deficit-de-talentos-de-ti-no-brasil/"),
        ])
 
    # ---------- 2. mulheres em STEM ----------
    with st.container(border=True):
        st.markdown("### 👩‍🔬 Mulheres em STEM")

        img_col, txt_col = st.columns([1, 3], vertical_alignment="center")
        with img_col:
            imagem("we_can_do_it.png", "“We Can Do It!”, cartaz de J. Howard Miller (1943)")
        with txt_col:
            st.markdown(
                "**STEM** é a sigla em inglês para Ciência, Tecnologia, Engenharia e "
                "Matemática (no dashboard, a área *CTEM*). A participação feminina nessas "
                "áreas ainda enfrenta desigualdades estruturais no Brasil e no mundo, apesar "
                "dos avanços recentes."
            )
            st.markdown(
                "**Graziela Simone Tonin**, professora do Insper e coordenadora de "
                "Engenharia de Computação, defende que a desigualdade **não nasce na "
                "universidade nem nas empresas: ela se perpetua e se potencializa lá**. "
                "Para ela, o problema começa na infância, quando as meninas deixam de ser "
                "incentivadas a explorar matemática, ciências e tecnologia."
            )
 
        e1, e2, e3 = st.columns(3)
        e1.markdown("**1. Infância**  \nFalta de estímulo e de representatividade nos "
                    "materiais didáticos e nas falas de professores.")
        e2.markdown("**2. Ensino superior**  \nAmbientes nem sempre acolhedores: "
                    "invisibilidade, microagressões, isolamento e dúvidas constantes "
                    "sobre a competência.")
        e3.markdown("**3. Mercado de trabalho**  \nDesconfiança, sobrecarga emocional e "
                    "estruturas que ignoram a maternidade, o racismo e a desigualdade "
                    "de renda.")
 
        st.markdown(
            "> “No mercado, elas ainda precisam provar o tempo todo que são capazes.”  \n"
            "> **Graziela Simone Tonin**, Insper"
        )
        st.caption("Ligação com os dados: em CTEM, as mulheres são cerca de um terço "
                   "dos diplomados no Sudeste (aba *Gênero por área*).")
 
        fontes([
            ("Insper: Mulheres em STEM",
             "https://www.insper.edu.br/pt/conteudos/acontece-no-insper/mulheres-em-stem-desafios-e-caminhos-para-a-equidade"),
        ])
 
    # ---------- 3. fuga de cérebros ----------
    with st.container(border=True):
        st.markdown("### 🧠 Fuga de cérebros")
 
        f1, f2 = st.columns([1, 2], vertical_alignment="center")
        f1.metric("Pesquisadores que o Brasil pode ter perdido", "~6,7 mil",
                  help="Estimativa do Centro de Gestão e Estudos Estratégicos (CGEE), "
                       "ligado ao Ministério da Ciência, Tecnologia e Inovação.")
        f2.markdown(
            "**Fuga de cérebros** é a saída de profissionais qualificados de um país "
            "para outro com melhores condições de emprego e salários mais altos. O "
            "Brasil é um dos países mais afetados da América Latina."
        )
        st.markdown(
            "Até os anos 2010, o Brasil **atraía pesquisadores de fora**, graças ao "
            "fortalecimento econômico e à relevância no uso de novas tecnologias. Com "
            "as crises políticas e econômicas a partir dessa década, o cenário mudou "
            "drasticamente."
        )
        fontes([
            ("Imaginie",
             "https://blog.imaginie.com.br/as-consequencias-a-longo-prazo-da-persistencia-da-fuga-de-cerebros-no-brasil/"),
        ])
